﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EventAnalysis
{
    public partial class Compare : Form
    {
        public Compare()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            hash2TextBox.Clear();
        }

        private void hash1OpenBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.Filter = "text file (*.txt)|*.txt";

            if(opd.ShowDialog() == DialogResult.OK)
            {
                hash1TextBox.Text = File.ReadAllText(opd.FileName);
            }
            else
            {
                MessageBox.Show("Load file failed!");
            }
        }

        private void hash2OpenBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog opd = new OpenFileDialog();
            opd.Filter = "text file (*.txt)|*.txt";

            if (opd.ShowDialog() == DialogResult.OK)
            {
                hash2TextBox.Text = File.ReadAllText(opd.FileName);
            }
            else
            {
                MessageBox.Show("Load file failed!");
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            hash1TextBox.Clear();
        }

        private void compareBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if(hash1TextBox.Text == hash2TextBox.Text)
                {
                    MessageBox.Show("The hash values are the same!");
                }
                else
                {
                    MessageBox.Show("Tampered file, the hashes do not match!");
                }
            }
            catch(Exception ex)
            {
                return;
            }
        }
    }
}
