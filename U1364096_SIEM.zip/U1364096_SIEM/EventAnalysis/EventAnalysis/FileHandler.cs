﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;
using System.Data;
using LumenWorks.Framework.IO.Csv;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace EventAnalysis
{
    class FileHandler
    {

        private DataTable dtable = new DataTable("CsvLogs"); // main table to load into
        private List<string> hasharray = new List<string>();
        private DataTable dtable2 = new DataTable("CsvLogs2"); // table for splitting large volumes
        private DataTable viewTable = new DataTable("CsvTable");
 
        private DataSet ds = new DataSet();

        //<subject>
        // reads csv file
        // and exports to gridview
        //</subject>
        public void readCsv(string path, DataGridView dgv)
        {
            using (CachedCsvReader csv = new CachedCsvReader(new StreamReader(path), false))
            {
                dgv.DataSource = csv;
            }
        }

        public void saveCurrent(string path)
        {
            csvToTable(path);
        }

        //<subject>
        // reads a csv file into
        // a DataTable making it easier
        // to manipulate, using OleDbConnection
        // as it has a faster load time than previous methods.
        // this is not as effective as Csv Reader - not to be used for large files
        //</sbject>
        public bool csvToTable(string path)
        {
            dtable.Clear();

            using (OleDbConnection odb = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" +
                Path.GetDirectoryName(path) + "\";Extended Properties='text;HDR=yes;FMT=Delimited(,)';"))
            {
                using (OleDbCommand cmd = new OleDbCommand(string.Format("select *from [{0}]",
                    new FileInfo(path).Name), odb))
                {
                    odb.Open();
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        adapter.Fill(dtable);
                    }
                }
            }
            return true;
        }

        //<subject>
        // splits the input
        // into two tables
        //</subject>
        public void splitInput()
        {
            var totalrows = dtable.Rows.Count - 1;
            var half = (totalrows / 2);

            dtable2.Merge(dtable);

            if (dtable.Rows.Count > 0 && dtable2.Rows.Count > 0)
            {
                for (int i = totalrows; i > half; i--)
                {
                    dtable.Rows.RemoveAt(i);

                }

                for (int i = half; i <= half && i > 0; i--)
                {
                    dtable2.Rows.RemoveAt(i);
                }
            }
        }

        //<subject>
        // saves the tbales
        // to a DataSet
        // </subject>
        public void saveTables()
        {
            if (ds.Tables.Contains("CsvLogs")) return;
            if (ds.Tables.Contains("CsvLogs2")) return;
            ds.Tables.Add(dtable);
            ds.Tables.Add(dtable2);
        }

        //<subject>
        // updates the view table
        //</subject>
        public DataTable updateView()
        {
            viewTable.Merge(dtable);
            return viewTable;
        }

        public DataTable updateViewNext()
        {
            viewTable.Merge(dtable2);
            return viewTable;
        }
 

                 
        public DataTable getDataTable1()
        {
            return dtable;
        }

        public DataTable getDataTable2()
        {
            return dtable2;
        }

        //<subject>
        // merges two tables
        //</subject>
        public bool mergeTables(DataTable dt1, DataTable dt2)
        {
            dt1.Merge(dt2); // adds all items that are in dt2 but not dt1 to dt1

            return true;
        }

        //<subject>
        // checks whether dataset
        // isEmpty, returns true
        // if dataset is empty
        //</subject>
        private bool datasetIsEmpty(DataSet dataset)
        {
            if(dataset.Tables.Count == 0)
            {
                return true;
            }
            return false;
        }

        public DataSet getDataSet()
        {
            return this.ds;
        }

        //<subject>
        // adds DataTable to DataSet
        // for later use
        //</subject>
        public void addDataTable(DataTable data)
        {
            ds.Tables.Add(data);
        }

        //<subject>
        // clears the DataSet of tables
        //</subject>
        public void clearDataSet(DataSet dataset)
        {
            if(!datasetIsEmpty(dataset))
            {
                dataset.Tables.Clear();
            }
            else
            {
                return;
            }
        }

        public void clearViewTable()
        {
            viewTable.Clear();
        }

        //<subject>
        // third trial for a faster csvReader
        // this method attempts to create a faster csv reader
        //</subject>
        public void tertiaryCsvReader(string path, DataGridView dgv)
        {
            FileStream fileStream = null;
            try
            {
                fileStream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            }
            catch (Exception ex)
            {
                return;
            }
            bool columnExists = false;
            using (StringReader reader = 
                new StringReader(new StreamReader(fileStream, Encoding.Default).ReadToEnd()))
            {
                while (reader.Peek() != -1)
                {
                    string line = reader.ReadLine();
                    if (line == null || line.Length == 0) continue;
  
                    string[] values = line.Split(',');
     
                    if (!columnExists)
                    {
                        for (int i = 0; i < values.Count(); i++)
                        {
                            dtable.Columns.Add("Column" + i);
                        }
                        columnExists = true;
                    }
                    DataRow row = dtable.NewRow();
                    for (int i = 0; i < values.Count(); i++)
                    {
                        row[i] = values[i];
                    }
                    dtable.Rows.Add(row);
                }
            }
            dgv.DataSource = dtable;
        }

        public string generateFileHash(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            using (var sha256 = new SHA1CryptoServiceProvider())
            {
                string hash = BitConverter
                        .ToString(sha256.ComputeHash(fs));

                return hash;
            }
        }

        public void saveHashToFile(string path, string hash)
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter(path);
            file.WriteLine(path, hash);
            file.Close();
        }

        public bool saveHashArray(string hash)
        {
            hasharray.Add(hash);

            return true;
        }
    }
}
