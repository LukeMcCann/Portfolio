﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Data.OleDb;
using System.IO;
using LumenWorks.Framework.IO.Csv;
using System.Runtime;

namespace EventAnalysis
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            csvDisplayGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            csvDisplayGrid.RowHeadersVisible = false;
            csvDisplayGrid.VirtualMode = true;
            csvDisplayGrid.ShowCellErrors = true;
            csvDisplayGrid.ShowCellToolTips = true; 
            csvDisplayGrid.ShowRowErrors = true;
            csvDisplayGrid.AllowDrop = true;
            ClearButton.Enabled = false;
        }

        private void  csvDisplayGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            csvDisplayGrid.Rows[e.RowIndex].ReadOnly = true;
            if (csvDisplayGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value == null)
            {
                csvDisplayGrid.Rows[e.RowIndex].ReadOnly = false;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        }

        string path;
        List<List<string>> records = new List<List<string>>();
        OpenFileDialog ofd = new OpenFileDialog();
        FileHandler handler = new FileHandler();

        private void csvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            csvDisplayGrid.DataSource = null;
            csvDisplayGrid.Rows.Clear();
            try
            {
                using (OpenFileDialog ofd = new OpenFileDialog()
                {
                    //Filter = "CSV|*.csv",
                    ValidateNames = true, Multiselect = false
                })
                {
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        path = ofd.FileName; // get filepath
                        openFileTextBox.Text = path;

                        if (File.Exists(path))
                        {
                            MessageBox.Show("Reading Csv, this can take up to 5 minutes!");
                            //if (handler.csvToTable(path)) // load csv file into datatable
                            try
                            {
                                handler.readCsv(path, csvDisplayGrid);
                                //handler.tertiaryCsvReader(path, csvDisplayGrid); //fastest csv reader method
                            }
                            catch(OutOfMemoryException ex)
                            {
                            } 
                            //handler.splitInput();
                            // MessageBox.Show("Csv Converted to DataTable!");
                        }
                        else
                        {
                           MessageBox.Show("File does not exist!");
                        }
                        ClearButton.Enabled = true;
                        csvDisplayGrid.ClearSelection();
                    }

                    // csvDisplayGrid.DataSource = handler.updateView(); // get view - alternative, does not work on large files
                    // handler.saveTables(); // save to dataset (for use with updateView()
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenFileButton_Click(object sender, EventArgs e)
        {
            csvToolStripMenuItem_Click(sender,e);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            csvDisplayGrid.DataSource = null;
            csvDisplayGrid.Rows.Clear();

            handler.clearViewTable();
            openFileTextBox.Clear();

            csvChart.Series.Clear();
            csvChart.Series.Add("Connections");
            csvChart.Titles.Clear();
            cleanUp();

            ClearButton.Enabled = false;
        }

        private void selectionBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(selectionBox.Text == "connection")
            {
                csvDisplayGrid.Sort(csvDisplayGrid.Columns["Column1"], ListSortDirection.Ascending);
            }

            if (selectionBox.Text == "dataType")
            {
                csvDisplayGrid.Sort(csvDisplayGrid.Columns["Column3"], ListSortDirection.Ascending);
            }
        }

        private void genChartButton_Click(object sender, EventArgs e)
        {
            fillConnectionChart();
        }

        private void fillConnectionChart()
        {
            try
            {
                cleanUp();
                csvChart.Series.Clear();
                csvChart.Series.Add("Connections");
                csvChart.Titles.Clear();

                int udpCount = 0;
                int tcpCount = 0;
                int icmpCount = 0;
                int other = 0;

                foreach (DataGridViewRow row in csvDisplayGrid.Rows)
                {
                    if (row.Cells["Column1"].Value.Equals("udp"))
                    {
                        udpCount++;
                    }

                    else if (row.Cells["Column1"].Value.Equals("tcp"))
                    {
                        tcpCount++;
                    }

                    else if (row.Cells["Column1"].Value.Equals("icmp"))
                    {
                        icmpCount++;
                    }

                    else
                    {
                        other++;
                    }

                }
            
                csvChart.Series["Connections"].Points.AddXY("udp", udpCount.ToString());
                csvChart.Series["Connections"].Points.AddXY("tcp", tcpCount.ToString());
                csvChart.Series["Connections"].Points.AddXY("icmp", icmpCount.ToString());
                csvChart.Series["Connections"].Points.AddXY("other", other.ToString());

                csvChart.DataSource = csvDisplayGrid;
                csvChart.Titles.Add("Frequency of Connection Types");
            }
            catch(OutOfMemoryException ex)
            {
                cleanUp();
                MessageBox.Show("Not enough available memory to process request!");
                return;
            }

        }


        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            String searchS = searchTextBox.Text.ToLower();

            for (int i = 0; i < csvDisplayGrid.Rows.Count; i++)
            {
                if (csvDisplayGrid.Rows[i].Cells[0].Value.ToString() == searchS)
                {
                    csvDisplayGrid.Rows[i].Cells[0].Selected = true;
                }

                if (csvDisplayGrid.Rows[i].Cells[1].Value.ToString() == searchS)
                {
                   csvDisplayGrid.Rows[i].Cells[1].Selected = true;
                }

                if (csvDisplayGrid.Rows[i].Cells[2].Value.ToString() == searchS)
                {
                    csvDisplayGrid.Rows[i].Cells[2].Selected = true;
                }

                if (csvDisplayGrid.Rows[i].Cells[3].Value.ToString() == searchS)
                {
                    csvDisplayGrid.Rows[i].Cells[3].Selected = true;
                }

                if (csvDisplayGrid.Rows[i].Cells[4].Value.ToString() == searchS)
                {
                    csvDisplayGrid.Rows[i].Cells[4].Selected = true;
                }

                if (csvDisplayGrid.Rows[i].Cells[5].Value.ToString() == searchS)
                {
                    csvDisplayGrid.Rows[i].Cells[5].Selected = true;
                }

                else
                {
                    continue;
                }
            }
        }


        private void saveAsTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            handler.saveCurrent(path);
        }

        private void connectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fillConnectionChart();
        }

        private void typeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fillTypeChart();
        }

        private void fillTypeChart()
        {
            using (MemoryFailPoint mf = new MemoryFailPoint(500))
            {
                try
                {
                    cleanUp();
                    csvChart.Series.Clear();
                    csvChart.Series.Add("Connections");
                    csvChart.Titles.Clear();

                    int privateCount = 0;
                    int publicCount = 0;
                    int domain_u = 0;
                    int ecr_i = 0;
                    int http = 0;
                    int smtp = 0;
                    int other = 0;

                    foreach (DataGridViewRow row in csvDisplayGrid.Rows)
                    {
                        if (row.Cells["Column2"].Value.Equals("private"))
                        {
                            privateCount++;
                        }

                        else if (row.Cells["Column2"].Value.Equals("public"))
                        {
                            publicCount++;
                        }

                        else if (row.Cells["Column2"].Value.Equals("domain_u"))
                        {
                            domain_u++;
                        }

                        else if (row.Cells["Column2"].Value.Equals("ecr_i"))
                        {
                            ecr_i++;
                        }

                        else if (row.Cells["Column2"].Value.Equals("http"))
                        {
                            http++;
                        }

                        else if (row.Cells["Column2"].Value.Equals("smtp"))
                        {
                            smtp++;
                        }

                        else
                        {
                            other++;
                        }

                    }

                    csvChart.Series["Connections"].Points.AddXY("private", privateCount.ToString());
                    csvChart.Series["Connections"].Points.AddXY("public", publicCount.ToString());
                    csvChart.Series["Connections"].Points.AddXY("domain_u", domain_u.ToString());
                    csvChart.Series["Connections"].Points.AddXY("ecr_i", ecr_i.ToString());
                    csvChart.Series["Connections"].Points.AddXY("http", http.ToString());
                    csvChart.Series["Connections"].Points.AddXY("smtp", smtp.ToString());
                    csvChart.Series["Connections"].Points.AddXY("other", other.ToString());

                    csvChart.DataSource = csvDisplayGrid;
                    csvChart.Titles.Add("Frewquency of Connection Types");
                }
                catch(OutOfMemoryException ex)
                {
                    cleanUp();
                    MessageBox.Show("Not enough available memory to process request!");
                    return;
                }
            }

        }


        private void cleanUp()
        {
            GC.Collect();
            MessageBox.Show("Requested Garbage Collection.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string hash = handler.generateFileHash(path);
            

            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.FileName = "hash.txt";
                sfd.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName))
                        sw.WriteLine(hash);

                    MessageBox.Show("Saved Hash Value: " + hash + " in " + sfd.FileName);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void currentFileFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Compare hashComDialog = new Compare();
            hashComDialog.Show();
        }

        private void saveHashToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string hash = handler.generateFileHash(path);
            handler.saveHashArray(hash);
        }

        private void lowerAppTableLayout_Paint(object sender, PaintEventArgs e)
        {

        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HelpForm form = new HelpForm();
            form.Show();
        }

        private void removeZerosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure to delete this item ??",
                                     "Confirm Delete!!",
                                     MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                removeZeroValues();
            }
            else
            {
                return;
            }
        }

        private void removeZeroValues()
        {
            foreach (DataGridViewRow row in csvDisplayGrid.Rows)
            {
                for (int i = 0; i < csvDisplayGrid.Columns.Count; i++)
                {
                    String cellValue = row.Cells[i].Value.ToString();

                    if(cellValue == "" || cellValue == "0" || cellValue == "0.00")
                    {
                        row.Cells[i].Value = null;
                    }
                }
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();

            sfd.Filter = "CSV (*.csv)|*.csv|txt files (*.txt)|*.txt|All files (*.*)|*.*";
            sfd.FileName = "untitled.csv";
            csvDisplayGrid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            csvDisplayGrid.SelectAll();
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                DataObject dataObject = csvDisplayGrid.GetClipboardContent();
                File.WriteAllText(sfd.FileName, dataObject.GetText(TextDataFormat.CommaSeparatedValue));

                csvDisplayGrid.ClearSelection();
            }
            else
            {
                return;
            }
        }
    }
}
