﻿namespace EventAnalysis
{
    partial class Compare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Compare));
            this.hash1OpenBtn = new System.Windows.Forms.Button();
            this.hash2OpenBtn = new System.Windows.Forms.Button();
            this.hash1TextBox = new System.Windows.Forms.TextBox();
            this.hash2TextBox = new System.Windows.Forms.TextBox();
            this.clear = new System.Windows.Forms.Button();
            this.clear2 = new System.Windows.Forms.Button();
            this.compareBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // hash1OpenBtn
            // 
            this.hash1OpenBtn.Location = new System.Drawing.Point(197, 48);
            this.hash1OpenBtn.Name = "hash1OpenBtn";
            this.hash1OpenBtn.Size = new System.Drawing.Size(75, 23);
            this.hash1OpenBtn.TabIndex = 0;
            this.hash1OpenBtn.Text = "Open Hash";
            this.hash1OpenBtn.UseVisualStyleBackColor = true;
            this.hash1OpenBtn.Click += new System.EventHandler(this.hash1OpenBtn_Click);
            // 
            // hash2OpenBtn
            // 
            this.hash2OpenBtn.Location = new System.Drawing.Point(197, 142);
            this.hash2OpenBtn.Name = "hash2OpenBtn";
            this.hash2OpenBtn.Size = new System.Drawing.Size(75, 23);
            this.hash2OpenBtn.TabIndex = 1;
            this.hash2OpenBtn.Text = "Open Hash";
            this.hash2OpenBtn.UseVisualStyleBackColor = true;
            this.hash2OpenBtn.Click += new System.EventHandler(this.hash2OpenBtn_Click);
            // 
            // hash1TextBox
            // 
            this.hash1TextBox.Location = new System.Drawing.Point(12, 64);
            this.hash1TextBox.Name = "hash1TextBox";
            this.hash1TextBox.Size = new System.Drawing.Size(179, 20);
            this.hash1TextBox.TabIndex = 2;
            // 
            // hash2TextBox
            // 
            this.hash2TextBox.Location = new System.Drawing.Point(12, 156);
            this.hash2TextBox.Name = "hash2TextBox";
            this.hash2TextBox.Size = new System.Drawing.Size(179, 20);
            this.hash2TextBox.TabIndex = 3;
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(197, 77);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(75, 23);
            this.clear.TabIndex = 4;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // clear2
            // 
            this.clear2.Location = new System.Drawing.Point(197, 171);
            this.clear2.Name = "clear2";
            this.clear2.Size = new System.Drawing.Size(75, 23);
            this.clear2.TabIndex = 5;
            this.clear2.Text = "Clear";
            this.clear2.UseVisualStyleBackColor = true;
            this.clear2.Click += new System.EventHandler(this.button4_Click);
            // 
            // compareBtn
            // 
            this.compareBtn.Location = new System.Drawing.Point(12, 226);
            this.compareBtn.Name = "compareBtn";
            this.compareBtn.Size = new System.Drawing.Size(260, 23);
            this.compareBtn.TabIndex = 6;
            this.compareBtn.Text = "Compare";
            this.compareBtn.UseVisualStyleBackColor = true;
            this.compareBtn.Click += new System.EventHandler(this.compareBtn_Click);
            // 
            // Compare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.compareBtn);
            this.Controls.Add(this.clear2);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.hash2TextBox);
            this.Controls.Add(this.hash1TextBox);
            this.Controls.Add(this.hash2OpenBtn);
            this.Controls.Add(this.hash1OpenBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(300, 300);
            this.MinimumSize = new System.Drawing.Size(200, 200);
            this.Name = "Compare";
            this.Text = "Compare";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button hash1OpenBtn;
        private System.Windows.Forms.Button hash2OpenBtn;
        private System.Windows.Forms.TextBox hash1TextBox;
        private System.Windows.Forms.TextBox hash2TextBox;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button clear2;
        private System.Windows.Forms.Button compareBtn;
    }
}