-----------------------------------README.TXT--------------------------------------

REQUIREMENTS:
.NET framework
2GB RAM
64Bit PC (Recommended)
https://www.microsoft.com/net/download

Future Functionality:
There are future plans to add the ability to directly load in SystemEventLog files to the gridview
and add additional features for analysis

Welcome to WinEventAnalysis a SIEM tool developed in C#!

Open Csv:
1. Click "open csv"
2. Select your csv file
3. select OK

You can also load a Csv from File -> Import -> Csv

Save Table:
1. Click File
2. Click Export...
3. Click Save..
4. Select save destination
5. Save File

Charts:
1. Select view
2. Select Charts
3. Select the chart to generate
(CSV Must be loaded first!)

Calculate HashSum and Save:
1. OpenCsv File
2. Select HashFile button
3. Select save destination
4. Save the file as *.txt

Compare Hash Files:
1. Select Tools
2. Select Compare currentfile-file...
3. Open two hash files pre-saved to text files
4. click compare

Sort by Column:
Simply click the header for the column, items will be sorted in ascending order, this can be
reversed by clicking the header again.

Sort by Category:
Using the combobox select the category you wish to sort by.

Search:
Enter a string and the first 5 columns will be searched for that string.
Any row containing the string will be highlighted!

RemoveZeroEntries:
1. Select Edit
2. Select removeZeroEntries

This will removr all "0" values from the table.

You can generate a Hashsum of your files by clicking the HashFile button.

Future Patch:
More checking coming soon, bug fixes and new "save" dialog when opening new files
to ensure no changes are lost

Author: Luke McCann - U1364096