package uk.ac.hud.u1557684.uni_notesv4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class NotesMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes_menu);

        Button mainMenuButton = (Button)findViewById(R.id.btnMainMenu);
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotesMenuActivity.this, MenuActivity.class);
                startActivity(i);
            }
        }); // close mainMenuButton

        Button note1Button = (Button)findViewById(R.id.btnNote1);
        note1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotesMenuActivity.this, Note1Activity.class);
                startActivity(i);
            }
        }); // close note1Button

        Button note2Button = (Button)findViewById(R.id.btnNote2);
        note2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotesMenuActivity.this, Note2Activity.class);
                startActivity(i);
            }
        }); // close note2Button

        Button note3Button = (Button)findViewById(R.id.btnNote3);
        note3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotesMenuActivity.this, Note3Activity.class);
                startActivity(i);
            }
        }); // close note3Button

    } // close onCreate
}
