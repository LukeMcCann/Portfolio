package uk.ac.hud.u1557684.uni_notesv4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class Note3Activity extends AppCompatActivity {

    EditText tfNoteBox;
    private final static String TEXT3="file3.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note3);

        // declare buttons and text field
        tfNoteBox = (EditText)findViewById(R.id.tfNoteBox);
        File myFile = new File("file3.txt");

        Button clearButton = (Button)findViewById(R.id.btnClear);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // clear text box
                tfNoteBox.setText("");
            }
        });

        Button readButton = (Button)findViewById(R.id.btnRead);
        readButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // write on SD card file data in the text box
                try {
                    InputStream in = openFileInput(TEXT3);
                    if (in != null) {
                        InputStreamReader tmp=new InputStreamReader(in);
                        BufferedReader reader=new BufferedReader(tmp);
                        String str;
                        StringBuilder buf=new StringBuilder();
                        while ((str = reader.readLine()) != null) {
                            buf.append(str+"");
                        }
                        in.close();
                        tfNoteBox.setText(buf.toString());
                    }
                }
                catch (java.io.FileNotFoundException e) {
                    // do nothing
                }
                catch (Throwable t) {
                    Toast.makeText(getBaseContext(),
                            "There was a problem reading your message.",
                            Toast.LENGTH_SHORT).show();
                }

            }

        });

        Button saveButton = (Button)findViewById(R.id.btnSave);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // write on text file
                try {
                    OutputStreamWriter out=
                            new OutputStreamWriter(openFileOutput(TEXT3, 0));
                    out.write(tfNoteBox.getText().toString());
                    out.close();
                    Toast.makeText(getBaseContext(),
                            "The message is now saved.",
                            Toast.LENGTH_SHORT).show();
                }
                catch (Throwable t) {
                    Toast.makeText(getBaseContext(),
                            "There was a problem saving your message.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        }); // close save method

        Button menuButton = (Button)findViewById(R.id.btnMenu);
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Note3Activity.this, NotesMenuActivity.class);
                startActivity(i);
            }
        });
    }
}
