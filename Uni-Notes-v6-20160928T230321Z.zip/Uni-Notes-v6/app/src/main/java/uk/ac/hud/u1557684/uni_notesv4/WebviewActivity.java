package uk.ac.hud.u1557684.uni_notesv4;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class WebviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        Button readingButton = (Button)findViewById(R.id.btnLink1);
        readingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create intent to take the user to the website
                Uri u = Uri.parse("http://www.humanities.manchester.ac.uk/studyskills/essentials/note-taking/taking_notes.html");
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                startActivity(i);
            }
        });

        Button referenceButton = (Button)findViewById(R.id.btnLink2);
        referenceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create intent to take the user to the website
                Uri u = Uri.parse("https://library.leeds.ac.uk/skills-referencing-harvard");
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                startActivity(i);
            }
        });

        Button freshersButton = (Button)findViewById(R.id.btnLink3);
        freshersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // create intent to take the user to the website
                Uri u = Uri.parse("http://university.which.co.uk/advice/preparing-for-university/freshers-what-to-expect-in-your-first-university-term");
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                startActivity(i);
            }
        });

        Button mainMenuButton = (Button)findViewById(R.id.btnMainMenu);
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(WebviewActivity.this, MenuActivity.class);
                startActivity(i);
            }
        });

    }
}
