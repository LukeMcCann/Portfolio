package uk.ac.hud.u1557684.uni_notesv4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button taskListButton = (Button)findViewById(R.id.btnTaskList);
        taskListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(MenuActivity.this, TaskListActivity.class);
                startActivity(a);
            }
        }); // close taskListButton

        Button noteMenuButton = (Button)findViewById(R.id.btnNoteMenu);
        noteMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(MenuActivity.this, NotesMenuActivity.class);
                startActivity(b);
            }
        }); // close noteMenuButton

        Button calculatorButton = (Button)findViewById(R.id.btnCalculator);
        calculatorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(MenuActivity.this, CalculatorActivity.class);
                startActivity(c);
            }
        }); // close calculatorButton

        Button toolsButton = (Button)findViewById(R.id.btnWebView);
        toolsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent d = new Intent(MenuActivity.this, WebviewActivity.class);
                startActivity(d);
            }
        }); // close toolsButton

        Button creditsButton = (Button)findViewById(R.id.btnCredits);
        creditsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(MenuActivity.this, CreditsActivity.class);
                startActivity(e);
            }
        }); // close creditsButton

        Button aboutButton = (Button)findViewById(R.id.btnAbout);
        aboutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent f = new Intent(MenuActivity.this, AboutActivity.class);
                startActivity(f);
            }
        }); // close aboutButton

    } // close onCreate

}
